﻿from django.shortcuts import render
from django.contrib.auth import login
from django.contrib.auth.forms import UserCreationForm

def login_view(request):
    return render(request, "accounts/login.html")

def client_register(request):
    return render(request, "accounts/register.html")
