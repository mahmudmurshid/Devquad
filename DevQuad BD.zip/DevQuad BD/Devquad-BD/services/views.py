﻿from django.shortcuts import render

def services(request):
    services_list = [
        {
            'id': 1,
            'name': 'Website Development',
            'description': 'Custom web applications built with modern technologies and best practices.',
            'icon': 'fas fa-laptop-code',
            'color': 'primary',
            'features': ['Responsive Design', 'E-commerce Solutions', 'CMS Development', 'API Integration', 'Database Design']
        },
        {
            'id': 2,
            'name': 'Security Testing',
            'description': 'Comprehensive security assessment to protect your digital assets from threats.',
            'icon': 'fas fa-user-shield',
            'color': 'success',
            'features': ['Penetration Testing', 'Vulnerability Assessment', 'Security Audit', 'Compliance Testing']
        },
        {
            'id': 3,
            'name': 'AI Services',
            'description': 'Intelligent solutions powered by artificial intelligence and automation.',
            'icon': 'fas fa-robot',
            'color': 'info',
            'features': ['AI Chatbots', 'Computer Vision', 'Predictive Analytics', 'Process Automation']
        },
        {
            'id': 4,
            'name': 'Advance Research',
            'description': 'Cutting-edge research in machine learning and data analysis.',
            'icon': 'fas fa-flask',
            'color': 'warning',
            'features': ['Machine Learning', 'Deep Learning', 'NLP', 'Data Analysis', 'Paper Writing']
        },
        {
            'id': 5,
            'name': 'Mobile Apps Development',
            'description': 'Native and cross-platform mobile applications for iOS and Android.',
            'icon': 'fas fa-mobile-alt',
            'color': 'danger',
            'features': ['iOS Development', 'Android Development', 'React Native', 'Flutter', 'API Integration']
        },
        {
            'id': 6,
            'name': 'IoT & Embedded Systems',
            'description': 'Innovative IoT solutions and embedded systems for smart applications.',
            'icon': 'fas fa-microchip',
            'color': 'secondary',
            'features': ['IoT Device Development', 'Embedded Software', 'Sensor Integration', 'Cloud Connectivity', 'Data Analytics']
        }
    ]
    
    return render(request, 'services/services.html', {'services': services_list})
